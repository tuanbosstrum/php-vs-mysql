<?php

class PostView{

    public function showAllPost($rows) {
        require_once 'trangchu.php' ;
    }
}
?>
